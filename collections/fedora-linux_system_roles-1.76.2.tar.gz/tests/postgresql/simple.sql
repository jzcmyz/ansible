CREATE TABLE mytable(
        mynumber int,
        name varchar(255)
);
INSERT INTO mytable VALUES (1, 'test');
