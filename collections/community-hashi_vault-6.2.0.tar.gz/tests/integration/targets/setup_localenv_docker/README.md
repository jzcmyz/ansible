# `setup_localenv_docker`
Uses `docker-compose` to set up required external dependencies for integration tests.

See the guides in the [devel documentation for the latest information](https://docs.ansible.com/ansible/devel/collections/community/hashi_vault/).

## Notes
* For requirements, see the files in `files/requirements/`.
