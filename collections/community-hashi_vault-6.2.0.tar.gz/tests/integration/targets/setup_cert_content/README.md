# `setup_cert_content`
Tiny role used for writing out the certificate when it was supplied as a string in vars (usually from `integration_config.yml`). Any target testing TLS connectivity that needs to verify the cert will need this.
