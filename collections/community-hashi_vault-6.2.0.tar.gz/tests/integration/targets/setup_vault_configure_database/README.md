# `setup_vault_configure_database`
Performs configuration of the database engine in Vault.
