# `setup_vault_configure`
Performs initial configuration of the Vault server with basic things intended to be used by many tests, such as a variety of kv secrets. Individual auth methods and other targets are responsible for their own setup.
